const { test } = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
const ts = require('typescript');

const root = path.resolve(__dirname, '..');
const records = [
  { eventDate: '2027-10-30', status: 'HELD' },
  { eventDate: '2027-10-30', status: 'CONFIRMED' },
  { eventDate: '2027-10-31', status: 'TENTATIVE' },
  { eventDate: '2027-10-15', status: 'CANCELLED' },
  { eventDate: '2027-11-02', status: 'HELD' },
];

const filterLib = {
  eq: (column, value) => (row) => row[column] === value,
  gte: (column, value) => (row) => row[column] >= value,
  lt: (column, value) => (row) => row[column] < value,
  inArray: (column, values) => (row) => values.includes(row[column]),
  and: (...predicates) => (row) => predicates.every((predicate) => predicate(row)),
};
const database = {
  select(fields) {
    return {
      from() {
        return {
          where(predicate) {
            const rows = records.filter(predicate).map(row => Object.fromEntries(
              Object.entries(fields).map(([key, field]) => [key, row[field]])
            ));
            return {
              limit(count) { return Promise.resolve(rows.slice(0, count)); },
              then(resolve, reject) { return Promise.resolve(rows).then(resolve, reject); },
            };
          },
        };
      },
    };
  },
};
class HttpError extends Error { constructor(status, message) { super(message); this.status = status; } }

// Fixed Philippine date keeps historical fixture dates deterministic.
class TestDate extends Date {
  constructor(...args) { super(...(args.length ? args : ['2027-10-14T16:00:00.000Z'])); }
  static now() { return new Date('2027-10-14T16:00:00.000Z').getTime(); }
}

function loadServerAvailability() {
  const file = path.join(root, 'src/lib/bookingAvailability.ts');
  const compiled = ts.transpileModule(fs.readFileSync(file, 'utf8'), {
    compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS },
  }).outputText;
  const mod = { exports: {} };
  const bookingWindowFile = path.join(root, 'src/lib/bookingWindow.ts');
  const bookingWindowJs = ts.transpileModule(fs.readFileSync(bookingWindowFile, 'utf8'), {
    compilerOptions: { target: ts.ScriptTarget.ES2022, module: ts.ModuleKind.CommonJS },
  }).outputText;
  const windowMod = { exports: {} };
  vm.runInNewContext(bookingWindowJs, { exports: windowMod.exports, module: windowMod, Date: TestDate, Intl, Error, Number });
  const requireMock = (name) => {
    if (name === '@/lib/bookingWindow') return windowMod.exports;
    if (name === 'drizzle-orm') return filterLib;
    if (name === '@/db') return { db: database };
    if (name === '@/db/schema') return { bookings: { eventDate: 'eventDate', status: 'status' } };
    if (name === '@/lib/http') return { HttpError };
    throw new Error('Unknown dependency: ' + name);
  };
  vm.runInNewContext(compiled, { exports: mod.exports, module: mod, require: requireMock, Date: TestDate, Intl, Map, Error });
  return mod.exports;
}

const availability = loadServerAvailability();

test('date validation rejects impossible dates and accepts leap day', () => {
  assert.equal(availability.isISODate('2028-02-29'), true);
  assert.equal(availability.isISODate('2027-02-29'), false);
  assert.equal(availability.isISODate('2027-13-01'), false);
  assert.equal(availability.isISODate('2027-10-30'), true);
  assert.equal(availability.isISOMonth('2027-10'), true);
  assert.equal(availability.isISOMonth('2027-00'), false);
});

test('only held and confirmed dates are blocked, duplicate legacy records do not leak data', async () => {
  const dates = await availability.reservedDatesForMonth('2027-10');
  assert.equal(dates.length, 1);
  assert.equal(dates[0].date, '2027-10-30');
  assert.equal(dates[0].status, 'CONFIRMED');
  assert.deepEqual(Object.keys(dates[0]).sort(), ['date', 'status']);
});

test('month bounds exclude next-month reservations', async () => {
  const dates = await availability.reservedDatesForMonth('2027-11');
  assert.equal(dates.length, 1);
  assert.equal(dates[0].date, '2027-11-02');
});

test('server rejects occupied date with 409, accepts a free date', async () => {
  const occupied='2027-10-30';
  await assert.rejects(availability.requireAvailableBookingDate(occupied), (e) => e.status === 409);
  await availability.requireAvailableBookingDate('2027-11-03');
  await assert.rejects(availability.requireAvailableBookingDate('2028-10-10'), (e) => e.status === 400 && /three months/i.test(e.message));
  await assert.rejects(availability.requireAvailableBookingDate('2027-10-14'), (e) => e.status === 400 && /Past dates/i.test(e.message));
});

test('both booking APIs use server-side reservation validation', () => {
  for (const name of ['app/api/bookings/route.ts', 'app/api/bookings/walk-in/route.ts']) {
    assert.match(fs.readFileSync(path.join(root, name), 'utf8'), /await requireAvailableBookingDate\(/);
  }
});

test('both forms use the shared date picker and repeat date availability check', () => {
  const wizard = fs.readFileSync(path.join(root, 'src/components/client/BookingWizard.tsx'),'utf8');
  assert.match(wizard, /<AvailableDatePicker/);
  assert.ok((wizard.match(/await assertAvailableDate\(/g) || []).length >= 2);
  const walkIn = fs.readFileSync(path.join(root, 'src/components/shared/WalkInBooking.tsx'),'utf8');
  assert.match(walkIn, /BookingWizard walkInRole=\{role\}/);
  const content = fs.readFileSync(path.join(root, 'src/components/ui/AvailableDatePicker.tsx'), 'utf8');
  assert.match(content, /disabled=\{unavailable\}/);
  assert.match(content, /\?month=/);
  assert.match(content, /status === 'HELD'/);
});
