import { requirePermission } from '@/lib/access';
import { route, ok, HttpError } from '@/lib/http';
import { db } from '@/db';
import { audit } from '@/lib/auth';
import { backupLogs, systemSettings } from '@/db/schema';
import { desc, eq } from 'drizzle-orm';
import { backupDispatchConfigured, backupDispatchMissing, dispatchBackup } from '@/lib/backup-dispatch';

export const runtime = 'nodejs';

export const GET = route(async () => {
  await requirePermission('backups.manage');
  const [logs, settings] = await Promise.all([
    db.select({ id: backupLogs.id, createdAt: backupLogs.createdAt, status: backupLogs.status, sizeBytes: backupLogs.sizeBytes, error: backupLogs.error })
      .from(backupLogs).orderBy(desc(backupLogs.createdAt)).limit(100),
    db.select().from(systemSettings).where(eq(systemSettings.id, 'main')),
  ]);
  return ok({ logs, configured: backupDispatchConfigured(), missingConfiguration: backupDispatchMissing(), provider: 'Cloudflare R2', runner: 'GitHub Actions', settings: settings[0] ?? null });
});

export const POST = route(async () => {
  const user = await requirePermission('backups.manage');
  if (!backupDispatchConfigured()) throw new HttpError(503, 'Backup runner is not configured on the web server.');
  const [log] = await db.insert(backupLogs).values({ performedBy: user.id, status: 'QUEUED' }).returning({ id: backupLogs.id });
  try {
    await dispatchBackup(log.id);
    await audit(user.id, 'BACKUP_REQUESTED', 'backup', log.id, { runner: 'github-actions', destination: 'cloudflare-r2' });
    return ok({ id: log.id, status: 'QUEUED', message: 'Backup queued. Refresh history to see the result.' }, 202);
  } catch (error) {
    await db.update(backupLogs).set({ status: 'FAILED', error: 'Unable to start GitHub Actions backup runner.' }).where(eq(backupLogs.id, log.id));
    throw error;
  }
});
