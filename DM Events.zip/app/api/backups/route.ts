import { requirePermission } from '@/lib/access';
import { route, ok } from '@/lib/http';
import { getBackupHistory, readBackupSchedule, saveBackup } from '@/lib/backupManager';
import { backupStorageSetup } from '@/lib/backupStorage';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';
export const maxDuration = 60;

export const GET = route(async () => {
  await requirePermission('backups.manage');
  const [history, schedule] = await Promise.all([getBackupHistory(), readBackupSchedule()]);
  const storage = backupStorageSetup();
  return ok({
    configured: storage.configured,
    setupIssues: storage.issues,
    schedulerConfigured: Boolean(process.env.CRON_SECRET && process.env.CRON_SECRET.length >= 32),
    history,
    schedule: { frequency: schedule?.frequency ?? 'OFF', nextRunAt: schedule?.nextRunAt ?? null, lastAttemptAt: schedule?.lastAttemptAt ?? null },
  });
});

export const POST = route(async () => {
  const user = await requirePermission('backups.manage');
  const result = await saveBackup('MANUAL', user.id);
  return ok({ backup: {
    id: result.id, status: result.status, source: result.source,
    createdAt: result.createdAt, rowCount: result.rowCount, tableCount: result.tableCount,
  } }, 201);
});
