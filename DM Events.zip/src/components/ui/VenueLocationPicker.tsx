'use client';

import { useEffect, useRef, useState } from 'react';
import { LoaderCircle, MapPin, Search, X } from 'lucide-react';

/* The Google Maps API is loaded only if the visitor opens the location picker.
   Browser-visible key MUST be restricted to permitted website referrers and APIs. */
type Coordinates = { lat: number; lng: number };
type MapsApi = { maps: {
  importLibrary: (name: string) => Promise<Record<string, any>>;
  Map: new (element: HTMLElement, options: Record<string, unknown>) => any;
  Marker: new (options: Record<string, unknown>) => any;
  Geocoder: new () => { geocode: (request: object) => Promise<{results: Array<{formatted_address:string}>}> };
} };
const googleApi = () => (window as unknown as {google?: MapsApi}).google;
let loader: Promise<MapsApi> | null = null;
function loadMaps(key: string): Promise<MapsApi> {
  const existing = googleApi();
  if (existing?.maps.importLibrary) return Promise.resolve(existing);
  if (loader) return loader;
  loader = new Promise<MapsApi>((resolve,reject) => {
    const script = document.createElement('script');
    script.src = `https://maps.googleapis.com/maps/api/js?key=${encodeURIComponent(key)}&v=weekly&loading=async`;
    script.async = true;
    script.onload = () => {
      const api = googleApi();
      if (api?.maps.importLibrary) resolve(api);
      else reject(new Error('Google Maps did not initialize. Verify that the Maps JavaScript API is enabled.'));
    };
    script.onerror = () => reject(new Error('Google Maps could not load. Check your internet connection and API key restrictions.'));
    document.head.appendChild(script);
  }).catch(error => { loader = null; throw error; });
  return loader;
}

export default function VenueLocationPicker({ id, value, onChange, onSelect, inputClassName = '' }: {
  id: string;
  value: string;
  onChange: (value: string) => void;
  onSelect?: (location: {address:string;lat:number;lng:number}) => void;
  inputClassName?: string;
}) {
  const [open,setOpen] = useState(false);
  const [loading,setLoading] = useState(false);
  const [error,setError] = useState('');
  const [picked,setPicked] = useState<{address:string;lat:number;lng:number}|null>(null);
  const [searching,setSearching] = useState(false);
  const mapContainer = useRef<HTMLDivElement>(null);
  const searchContainer = useRef<HTMLDivElement>(null);
  const apiKey = process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY ?? '';
  useEffect(() => {
    if (!open || !apiKey) return;
    let alive = true;
    let stop: (()=>void) | null = null;
    setLoading(true); setError(''); setPicked(null);
    void (async () => {
      try {
        const google = await loadMaps(apiKey);
        await Promise.all([google.maps.importLibrary('maps'),google.maps.importLibrary('places'),google.maps.importLibrary('geocoding')]);
        if (!alive || !mapContainer.current || !searchContainer.current) return;
        const start: Coordinates = {lat:15.0794,lng:120.6200}; // Pampanga default
        const map = new google.maps.Map(mapContainer.current,{center:start,zoom:10,mapTypeControl:false,streetViewControl:false,fullscreenControl:false,gestureHandling:'cooperative'});
        const marker = new google.maps.Marker({map,position:start,visible:false});
        const geocoder = new google.maps.Geocoder();
        const autocompleteHost = searchContainer.current;
        const autocompleteLib = await google.maps.importLibrary('places');
        if (!alive || !autocompleteHost) return;
        const element = new autocompleteLib.PlaceAutocompleteElement({includedRegionCodes:['ph']}) as HTMLElement;
        element.style.width = '100%';
        element.setAttribute('aria-label','Find a venue or address in the Philippines');
        autocompleteHost.replaceChildren(element);
        const selectPlace = async (event: Event) => {
          try {
            setSearching(true);
            const prediction = (event as Event & {placePrediction?:{toPlace:()=>any}}).placePrediction;
            if (!prediction) return;
            const place = prediction.toPlace();
            await place.fetchFields({fields:['formattedAddress','location','displayName']});
            if (!alive || !place.location) return;
            const lat = place.location.lat(); const lng = place.location.lng();
            if (!Number.isFinite(lat) || !Number.isFinite(lng)) return;
            const address = place.formattedAddress || place.displayName || '';
            map.panTo({lat,lng}); map.setZoom(16); marker.setPosition({lat,lng});marker.setVisible(true);
            setPicked({address,lat,lng});
          } catch { if (alive) setError('Could not resolve that venue. Try selecting it on the map.'); }
          finally { if (alive) setSearching(false); }
        };
        element.addEventListener('gmp-select',selectPlace);
        const click = map.addListener('click', async (event: {latLng?:{lat:()=>number;lng:()=>number}}) => {
          if (!event.latLng) return;
          const lat = event.latLng.lat();const lng = event.latLng.lng();
          marker.setPosition({lat,lng});marker.setVisible(true);
          setSearching(true);setError('');
          try {
            const result = await geocoder.geocode({location:{lat,lng}});
            if (alive) setPicked({address:result.results[0]?.formatted_address || `${lat.toFixed(6)}, ${lng.toFixed(6)}`,lat,lng});
          } catch { if (alive) setPicked({address:`${lat.toFixed(6)}, ${lng.toFixed(6)}`,lat,lng}); }
          finally { if (alive) setSearching(false); }
        });
        stop = () => { click.remove();element.removeEventListener('gmp-select',selectPlace); element.remove();marker.setMap(null); };
      } catch (caught) { if (alive) setError(caught instanceof Error ? caught.message : 'Could not open Google Maps.'); }
      finally { if (alive) setLoading(false); }
    })();
    return () => {alive=false;stop?.();};
  },[open,apiKey]);
  useEffect(() => {
    if (!open) return;
    const escape = (event: KeyboardEvent) => { if (event.key === 'Escape') setOpen(false); };
    window.addEventListener('keydown',escape);
    return () => window.removeEventListener('keydown',escape);
  },[open]);
  return <div className="space-y-2">
    <div className="flex min-w-0 flex-col gap-2 sm:flex-row">
      <input id={id} value={value} onChange={event=>onChange(event.target.value)} maxLength={2000} placeholder="Enter a venue or select an address on the map" className={`${inputClassName} min-w-0 flex-1`} />
      <button type="button" onClick={()=>setOpen(true)} disabled={!apiKey} className="inline-flex min-h-11 items-center justify-center gap-2 rounded-xl border border-[#b7cbdc] bg-white px-4 text-sm font-semibold text-[#17486c] transition hover:bg-blue-50 disabled:cursor-not-allowed disabled:opacity-50"><MapPin size={17}/> Pick on map</button>
    </div>
    {!apiKey && <p className="text-xs text-amber-700">Google Maps is not configured yet. You can still type the venue address manually.</p>}
    {open && <div role="dialog" aria-modal="true" aria-label="Choose event location" className="fixed inset-0 z-[200] flex items-end justify-center bg-[#071f3b]/75 p-0 sm:items-center sm:p-4" onMouseDown={event=>{if(event.currentTarget===event.target)setOpen(false);}}>
      <div className="flex max-h-[95dvh] w-full max-w-3xl flex-col gap-3 overflow-y-auto rounded-t-2xl bg-white p-4 shadow-2xl sm:max-h-[90dvh] sm:rounded-2xl sm:p-6">
        <div className="flex items-center justify-between gap-3"><div><h2 className="text-xl font-bold text-[#143a56]">Choose your event location</h2><p className="mt-1 text-xs text-slate-600">Search an address or tap the map to place the event marker.</p></div><button type="button" aria-label="Close location picker" onClick={()=>setOpen(false)} className="rounded-full border p-2"><X size={20}/></button></div>
        <div ref={searchContainer} className="min-h-12 rounded-xl border border-slate-200 bg-slate-50 p-1" aria-label="Search for locations"><span className="flex items-center gap-2 p-2 text-sm text-slate-500"><Search size={16}/> {loading?'Loading location search…':'Search for a venue in the Philippines'}</span></div>
        <div ref={mapContainer} className="min-h-[250px] w-full rounded-xl bg-[#e5eef4] sm:min-h-[380px]" role="region" aria-label="Interactive Google map"/>
        {error && <p role="alert" className="rounded-lg bg-rose-50 p-3 text-sm text-rose-700">{error}</p>}
        {searching && <p role="status" className="flex items-center gap-2 text-sm text-slate-600"><LoaderCircle className="animate-spin" size={16}/> Finding this address…</p>}
        {picked && <p className="rounded-xl border border-blue-200 bg-blue-50 p-3 text-sm text-[#173b58]"><MapPin className="mr-2 inline" size={16}/>{picked.address}</p>}
        <div className="flex justify-end gap-2"><button type="button" onClick={()=>setOpen(false)} className="rounded-xl border px-4 py-2 text-sm font-semibold">Cancel</button><button type="button" disabled={!picked || searching} onClick={()=>{if(picked){onChange(picked.address);onSelect?.(picked);setOpen(false);}}} className="rounded-xl bg-[#0b4d98] px-5 py-2 text-sm font-semibold text-white disabled:opacity-40">Use this location</button></div>
      </div>
    </div>}
  </div>;
}
