import {requirePermission} from '@/lib/access';
import {notificationOutbox} from '@/db/schema';
import {notificationRows} from '@/lib/notifications/enqueue';
import {tryImmediateDelivery} from '@/lib/notifications/worker';
import {route,ok,readJson,HttpError} from '@/lib/http';import {statusInput} from '@/lib/validators';import {bookings,bookingHistory,auditLogs} from '@/db/schema';import {db} from '@/db';import {and,eq,ne,inArray,sql} from 'drizzle-orm';
export const POST=route(async(req,ctx:{params:Promise<{id:string}>})=>{
 const u=await requirePermission('bookings.status');const {id}=await ctx.params;const v=statusInput.parse(await readJson(req));
 let result: {status: typeof v.status; conflicts: {reference:string;status:string;venue:string}[];changed:boolean};
 try { result=await db.transaction(async(tx)=>{
  const [b]=await tx.select().from(bookings).where(eq(bookings.id,id)).for('update');if(!b)throw new HttpError(404,'Booking not found');
  // Serialize decisions for the same event date to avoid simultaneous incompatible holds.
  await tx.execute(sql`SELECT pg_advisory_xact_lock(hashtext(${b.eventDate}))`);
  if(b.status==='CANCELLED'&&v.status!=='CANCELLED')throw new HttpError(409,'Cancelled bookings may not be reactivated through this action');
  if(v.status==='CONFIRMED'&&(v.bookedValue===undefined||v.bookedValue===null)&&b.bookedValue===null)throw new HttpError(400,'Record an agreed booking value before confirming');
  if(v.status==='CONFIRMED'&&(v.bookedValue===null||(v.bookedValue===undefined?Number(b.bookedValue):v.bookedValue)<=0))throw new HttpError(400,'Booking value must be greater than zero');
  const conflicts=await tx.select({reference:bookings.reference,status:bookings.status,venue:bookings.venue}).from(bookings).where(and(eq(bookings.eventDate,b.eventDate),ne(bookings.id,id),inArray(bookings.status,['HELD','CONFIRMED'])));
  if(['HELD','CONFIRMED'].includes(v.status)&&conflicts.length)throw new HttpError(409,`Date unavailable: ${conflicts.map(x=>x.reference+' ('+x.status+')').join(', ')}. A held or confirmed event already occupies this date. Choose another date or cancel/release the existing reservation.`);
  const newConfirmedAt=v.status==='CONFIRMED'?b.confirmedAt||new Date():null;
  await tx.update(bookings).set({status:v.status,reviewNote:v.note??b.reviewNote,bookedValue:v.bookedValue===undefined?b.bookedValue:v.bookedValue===null?null:String(v.bookedValue),confirmedAt:newConfirmedAt,updatedAt:new Date(),cancellationRequestedAt:v.status==='CANCELLED'?null:b.cancellationRequestedAt}).where(eq(bookings.id,id));
  const [history]=await tx.insert(bookingHistory).values({bookingId:id,actorId:u.id,fromStatus:b.status,toStatus:v.status,note:v.note||'Status updated',overrideConflict:false}).returning({id:bookingHistory.id});
  // Keep audit and booking state atomic, so the user never sees a false failure after a committed save.
  await tx.insert(auditLogs).values({actorId:u.id,action:'BOOKING_STATUS_UPDATED',targetType:'booking',targetId:id,details:{status:v.status,overrideConflict:false}});
  const valueChanged = v.bookedValue!==undefined && (
    v.bookedValue===null ? b.bookedValue!==null : b.bookedValue===null || Number(b.bookedValue)!==v.bookedValue
  );
  const detailsChanged = (v.note!==undefined && v.note!==(b.reviewNote||'')) || valueChanged;
  const shouldNotify = b.status!==v.status || detailsChanged;
  if(shouldNotify){
    const kind=b.status!==v.status?'BOOKING_STATUS_CHANGED':'BOOKING_DETAILS_UPDATED';
    const notifications=notificationRows(b,kind,history.id,{status:v.status});
    if(notifications.length)await tx.insert(notificationOutbox).values(notifications).onConflictDoNothing();
  }
  return {status:v.status,conflicts,changed:shouldNotify};
 }); } catch(error) {
  const e=error as {code?:string;cause?:{code?:string;constraint_name?:string};constraint_name?:string};
  if(e.code==='23505'||e.cause?.code==='23505')throw new HttpError(409,'This date was just reserved by another event. Refresh the calendar and choose a free date.');
  throw error;
 }
 // Delivery is best-effort: a gateway outage must not turn a committed save into HTTP 500.
 if(result.changed){try{await tryImmediateDelivery(id);}catch(error){console.error('Notification dispatch delayed for booking',id,error);}}
 return ok(result);
});
