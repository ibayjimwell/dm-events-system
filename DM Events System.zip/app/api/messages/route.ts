import {route,ok,readJson,HttpError} from '@/lib/http';import {requireActor,audit} from '@/lib/auth';import {db} from '@/db';import {messages,messageReads,mediaAssets} from '@/db/schema';import {eq,and} from 'drizzle-orm';import {readBooking,readConversation} from '@/models/read';import {messageInput, messageReadInput} from '@/lib/validators';
export const GET=route(async(req)=>{const u=await requireActor();const id=new URL(req.url).searchParams.get('bookingId')||'';if(!id)throw new HttpError(400,'bookingId required');const data=await readConversation(id,u);return ok({messages:data});});
export const POST=route(async(req)=>{
 const u=await requireActor('CLIENT','COORDINATOR');const v=messageInput.parse(await readJson(req));await readBooking(v.bookingId,u);
 if(v.assetId){const [a]=await db.select().from(mediaAssets).where(and(eq(mediaAssets.id,v.assetId),eq(mediaAssets.uploadedBy,u.id),eq(mediaAssets.kind,'MESSAGE')));if(!a||a.bookingId)throw new HttpError(400,'Attachment unavailable');}
 const [m]=await db.transaction(async tx=>{const [newMessage]=await tx.insert(messages).values({bookingId:v.bookingId,senderId:u.id,body:v.body,assetId:v.assetId||null}).returning();if(v.assetId)await tx.update(mediaAssets).set({bookingId:v.bookingId}).where(eq(mediaAssets.id,v.assetId));return [newMessage];});
 await audit(u.id,'MESSAGE_SENT','booking',v.bookingId);return ok({message:m},201);
});
export const PATCH=route(async(req)=>{const u=await requireActor();const {bookingId}=messageReadInput.parse(await readJson(req));await readBooking(bookingId,u);await db.insert(messageReads).values({bookingId,userId:u.id,lastReadAt:new Date()}).onConflictDoUpdate({target:[messageReads.bookingId,messageReads.userId],set:{lastReadAt:new Date()}});return ok({success:true});});
