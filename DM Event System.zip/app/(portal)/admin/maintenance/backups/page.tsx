import {pagePermission} from '@/lib/access';
import Backups from '@/components/admin/Backups';
export default async function Page(){await pagePermission('backups.manage');return <Backups/>;}
