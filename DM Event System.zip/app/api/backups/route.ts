import {desc} from 'drizzle-orm';
import {db} from '@/db';
import {backupLogs} from '@/db/schema';
import {createBackup} from '@/lib/backup';
import {requirePermission} from '@/lib/access';
import {audit} from '@/lib/auth';
import {route,ok} from '@/lib/http';
export const runtime='nodejs';
export const GET=route(async()=>{
 await requirePermission('backups.manage');
 const logs=await db.select({id:backupLogs.id,createdAt:backupLogs.createdAt,status:backupLogs.status,sizeBytes:backupLogs.sizeBytes,storageKey:backupLogs.storageKey,error:backupLogs.error}).from(backupLogs).orderBy(desc(backupLogs.createdAt)).limit(100);
 const configured=Boolean(process.env.BACKUP_ENCRYPTION_KEY&&process.env.BACKUP_S3_BUCKET&&process.env.BACKUP_S3_ACCESS_KEY_ID&&process.env.BACKUP_S3_SECRET_ACCESS_KEY);
 return ok({logs,configured});
});
export const POST=route(async()=>{
 const staff=await requirePermission('backups.manage');
 const result=await createBackup(staff.id);
 await audit(staff.id,'BACKUP_CREATED','backup',result.id);
 return ok({backup:result},201);
});
