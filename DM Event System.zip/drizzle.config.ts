import 'dotenv/config';
import { defineConfig } from 'drizzle-kit';
export default defineConfig({ schema: './src/db/schema.ts', out: './drizzle', dialect: 'postgresql', dbCredentials: { url: process.env.MIGRATION_DATABASE_URL || process.env.DATABASE_URL! }, verbose: true, strict: true });
